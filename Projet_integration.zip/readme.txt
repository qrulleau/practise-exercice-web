Typographie
TITRE	Quicksand
TEXTE	Nunito Sans

Couleurs

primary : #0B1460
secondary : #2667FF